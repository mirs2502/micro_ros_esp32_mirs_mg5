// generated from rosidl_generator_c/resource/idl.h.em
// with input from builtin_interfaces:msg/Time.idl
// generated code does not contain a copyright notice

#ifndef BUILTIN_INTERFACES__MSG__TIME_H_
#define BUILTIN_INTERFACES__MSG__TIME_H_

#include "builtin_interfaces/msg/detail/time__struct.h"
#include "builtin_interfaces/msg/detail/time__functions.h"
#include "builtin_interfaces/msg/detail/time__type_support.h"

#endif  // BUILTIN_INTERFACES__MSG__TIME_H_
