// generated from rosidl_generator_c/resource/idl.h.em
// with input from geometry_msgs:msg/AccelStamped.idl
// generated code does not contain a copyright notice

#ifndef GEOMETRY_MSGS__MSG__ACCEL_STAMPED_H_
#define GEOMETRY_MSGS__MSG__ACCEL_STAMPED_H_

#include "geometry_msgs/msg/detail/accel_stamped__struct.h"
#include "geometry_msgs/msg/detail/accel_stamped__functions.h"
#include "geometry_msgs/msg/detail/accel_stamped__type_support.h"

#endif  // GEOMETRY_MSGS__MSG__ACCEL_STAMPED_H_
